/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef CONTROL_H
#define CONTROL_H

#include <project.h>

void Control_Init();
void Control_Start();
void Control_Update();

#endif

/* [] END OF FILE */
