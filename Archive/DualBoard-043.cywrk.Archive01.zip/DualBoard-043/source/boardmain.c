/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <stdio.h>
#include <project.h>
#include "control.h"
#include "i2c.h"
#include "pid.h"
#include "encoder.h"
#include "odom.h"
#include "motor.h"
#include "ultrasonic.h"
#include "infrared.h"
#include "time.h"
#include "debug.h"

uint8 calibration_enabled;


int main()
{       
    CyGlobalIntEnable;      /* Enable global interrupts */
    
    /* Start this right away so that we debug as soon as possible */
    Debug_Init();
    Debug_Start();
        
    Control_Init();
    Time_Init();
    I2c_Init();
    Encoder_Init();
    Odom_Init();
    Motor_Init();

    Time_Start();
    I2c_Start();
    PID_Start();
    Encoder_Start();
    Odom_Start();
    Motor_Start();
    
    Control_Start();
    
    for(;;)
    {
        MainLoop_Pin_Write( ~MainLoop_Pin_Read() );
        /* Update any control changes */
        Control_Update();
        
        if (calibration_enabled)
        {
            /* An explanation for how calibration can work:
                    1. Calibration data will be stored in a file on the Raspberry Pi
                        Note: That eliminates the need for any type of NVRAM or additional peripheral hardware
                    2. A calibration program will be run from the Raspberry Pi.  It will communicate with the Psoc
                       boards over the I2C bus using the control register to invoke calibration and another address
                        (2 bytes) to read each value from the Psoc.
                        Note: There will be a known number of entries (150) in the calibration array
                    3. To start calibration, the calibration program will set the calibration bit in the control
                       register
                    4. The Psoc will then set the calibration bit in the status register and start calibration
                         a. Psoc with run the motor from full forward to stop
                         b. Measure motor speed and calculate an average count/sec and capture min/max pwm values
                         c. Store the pwm min/max values for each count/sec calulation
                         d. Calculate an average pwm from the min/max values
                         e. Interpolate between each sampled count/sec to fill out the PWM array
                    5. The calibration program will poll the calibration bit in the status register waiting for it to
                       be cleared
                    6. The Psoc will clear the calibration bit in the status register when calibration is complete
                        Note: It may be better to write the first calibration value into the calibration register before
                              clearing the calibration bit in the status register
                    7. Now, how to handshake and transfer the data?
                        a. After clearing the calibration bit of the status register, the Psoc will write a value from
                            calibration array to the I2C calibration register and poll waiting for the value to be 
                            cleared by the calibration program
                        b. The calibration program will poll the calibration register waiting for its value to become
                            non-zero.  After reading the calibration value, the calibration program will clear the 
                            calibration register
                        c. Steps a. and b. will repeat until all the values have been written
                        d. After Psoc writes the last calibration value to the calibration register, it will write the
                            value 0xFFFF signifying the end of the transmission.
             */
            Motor_Calibrate();
        }
        else
        {        
            /* Update encoder-related values */
            Encoder_Update();
            /* Update the odometry calculation */
            Odom_Update();
            /* Apply the velocity command to PID */
            PID_Update();
            /* Read the infrared sensors */
            Infrared_Measure();
            /* Read the ultrasonic sensors */
            Ultrasonic_Measure();
        }
    }
}

/* [] END OF FILE */
