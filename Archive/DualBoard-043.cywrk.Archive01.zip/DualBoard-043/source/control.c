/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "control.h"
#include "i2c.h"
#include "encoder.h"
#include "motor.h"
#include "time.h"

/* The purpose of this module is to handle control changes to the system.
   The only thing considered at this point is shutting down the motors properly.
 */

#define POWER_ON_MOTOR      (0x0001)
#define CLEAR_ENCODER_COUNT (0x0002)

extern uint8 calibration_enabled;

static uint32 last_time;

void Control_Init()
{
    last_time = millis();
    calibration_enabled = 0;
}

void Control_Start()
{    
    /* Note: I'm not sure what to do here, was thinking that this could be a way to enabled/disabled features at startup */
    uint16 control = I2c_ReadControl();
    
    /* Assigne a bit to control for calibration
    calibration_enabled  = control & CALIBRATION_ENABLED;
     */
}

void Control_Update()
{
    uint8 clear_encoder_count;
    uint16 control;
    
    control = I2c_ReadControl();
    
    clear_encoder_count = control & CLEAR_ENCODER_COUNT;
    if (clear_encoder_count)
    {
        Encoder_Reset();
    }
    
}

/* [] END OF FILE */
