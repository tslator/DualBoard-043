/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "motor.h"
#include "utils.h"
#include "debug.h"
#include "hwconfig.h"
#include "encoder.h"
#include "time.h"
#include "math.h"

/* Add a link to the HB25 data sheet
   Ref:
 */

#define HB25_ENABLE_BIT (0)
#define HB25_PWM_BIT (1)
#define HB25_ENABLE (0)
#define HB25_DISABLE (1)

#define MIN_PWM_COUNT (800)
#define CNTR_PWM_COUNT (1500)
#define MAX_PWM_COUNT (2200)

#define PWM_PADDING (200)

/* Note: While technically the motors are reverse relative to each other, it is clearer to hide this difference from
   the code.  Therefore, while the constants will actually be different values, the functionality will be the same
   between the boards driving the motors.  We'll handle this at compile time so there is no runtime difference.

                            Left    Right
        PWM_FULL_FORWARD |  2000  | 1000  |
        PWM_STOP         |  1500  | 1500  |
        PWM_FULL_REVERSE |  1000  | 2000  |
        PWM_DECREMENT    |   -1   |   1   |
        PWM_INCREMENT    |    1   |  -1   |
        PWM_CAL_STEP     |   10   |  10   |
        PWM_MIN          |  2000  | 1500  |
        PWM_MAX          |  1500  | 1000  |
 */

#ifdef LEFT_BOARD
#define PWM_FULL_FORWARD (2000)
#define PWM_STOP         (1500)
#define PWM_FULL_REVERSE (1000)
#define PWM_DECREMENT    (-1)
#define PWM_INCREMENT    (1)
#define PWM_MIN          (PWM_FULL_FORWARD)
#define PWM_MAX          (PWM_STOP)
#define PWM_FACTOR(value) ((value < 0) ? -500 : 0)
#elif defined RIGHT_BOARD
#define PWM_FULL_FORWARD (1000)
#define PWM_STOP         (1500)
#define PWM_FULL_REVERSE (2000)
#define PWM_DECRMENT     (1)
#define PWM_INCREMENT    (-1)
#define PWM_MIN          (PWM_STOP)
#define PWM_MAX          (PWM_FULL_FORWARD)
#define PWM_FACTOR(value) ((value > 0) ? +500 : 0)
#else
    #error "You haven't defined a board, e.g. LEFT_BOARD or RIGHT_BOARD"
#endif

#define PWM_RANGE        (500) // 2000 - 1500 = 500, 1500 - 1000 = 500
#define PWM_CAL_STEP     (10)
#define PWM_SETTLE_TIME  (200)

/* 
    The number markers depends on the calibration step (PWM_CAL_STEP), e.g., smaller step more values and vice versa
 */
#define MAX_NUM_MARKERS (PWM_RANGE/PWM_CAL_STEP)
#define MAX_NUM_CAL_ENTRY (300)
#define MIN_CAL_ENTRY (0)
#define MAX_CAL_ENTRY (299)

#define MAX_NUM_CPS_ENTRY (150)
#define MIN_CPS_ENTRY (0)
#define MAX_CPS_ENTRY (MAX_NUM_CPS_ENTRY - 1)

typedef struct
{
    uint16 pwm_min;
    uint16 pwm_max;
} CALIBRATION_ENTRY;

static CALIBRATION_ENTRY cal_cps_to_pwm[MAX_NUM_CAL_ENTRY];
static uint8 markers[MAX_NUM_MARKERS];

static uint16 map_cps_to_pwm[MAX_NUM_CPS_ENTRY] = {1500, 1505, 1510, 1515, 1520, 1525, 1530, 1531, 1532, 1533, 
                                                   1534, 1535, 1536, 1540, 1542, 1544, 1546, 1548, 1550, 1550, 
                                                   1552, 1554, 1556, 1558, 1560, 1560, 1561, 1562, 1563, 1564, 
                                                   1565, 1566, 1570, 1573, 1576, 1579, 1580, 1581, 1582, 1583, 
                                                   1584, 1585, 1586, 1590, 1592, 1594, 1596, 1598, 1600, 1600, 
                                                   1603, 1606, 1609, 1610, 1611, 1612, 1613, 1614, 1615, 1616, 
                                                   1620, 1623, 1626, 1629, 1630, 1632, 1634, 1636, 1638, 1640, 
                                                   1642, 1644, 1646, 1648, 1650, 1651, 1652, 1653, 1654, 1655, 
                                                   1656, 1657, 1660, 1663, 1666, 1670, 1671, 1672, 1673, 1674, 
                                                   1675, 1676, 1677, 1680, 1682, 1684, 1686, 1688, 1690, 1692, 
                                                   1694, 1696, 1698, 1700, 1700, 1702, 1704, 1706, 1708, 1710, 
                                                   1712, 1714, 1716, 1718, 1720, 1723, 1726, 1729, 1732, 1735, 
                                                   1736, 1737, 1738, 1739, 1740, 1741, 1742, 1743, 1744, 1745, 
                                                   1750, 1751, 1752, 1753, 1754, 1755, 1756, 1760, 1763, 1766, 
                                                   1769, 1770, 1771, 1772, 1773, 1774, 1775, 1776, 1777, 1780};


static int16 CalcCountsPerSecond(uint32 delay)
{
    int32 count_start;
    int32 count_end;
    int32 delta;
    
    count_start = (int32) Phase_Counter_ReadCounter();
    CyDelay(500);
    count_end = (int32) Phase_Counter_ReadCounter();
    delta = count_end - count_start;
    return (delta*MS_IN_SEC)/delay;
}

/*
    Recommendation by Parallax:

    Safe Power-Up and Power-Down
    Remember, because the HB-25 responds to pulses like a servo, changing states on your microcontroller’s
    I/O pins at startup and shutdown can affect the HB-25 and set it into an unintended state. This includes
    the I/O pins changing between input and output as well as between output high and output low.
    If your microcontroller is powered up or powered down while the HB-25 is powered up, the
    HB-25 could receive a false trigger. To prevent this, use one of the following options:
    • Most reliable option:
    1. Power the microcontroller up first, using code that forces the program to wait until the
    HB-25 is powered up before sending pulses. Code examples are provided below.
    2. Power up the HB-25 for operation.
    3. When shutting down your application, cut off power to the HB-25 first.
    4. Power down your microcontroller last.
    • Or, power the HB-25 and the microcontroller at the same time using a double-post (dual-circuit)
    switch.
    • If there is the possibility that the HB-25 will be on before your microcontroller, use the example
    code as mentioned above to ensure that the HB-25 is properly initialized when the
    microcontroller is powered on. The I/O line connected to the HB-25 should be made LOW either
    before or immediately after the HB-25 powers up. If this does not happen the HB-25 may fail to
    respond to incoming pulses.
    If your application poses any potential safety risk and you need the HB-25 to shut off the motors when
    the microcontroller has lost power or has malfunctioned, enable the Timeout Feature described below
    before operation.

 */

void Motor_Init()
{
    int ii;
    
    HB25_Enable_Pin_Write(HB25_DISABLE);
    
    cal_cps_to_pwm[0].pwm_min = PWM_STOP;
    cal_cps_to_pwm[0].pwm_max = PWM_STOP;
    for (ii = MIN_CAL_ENTRY; ii < MAX_NUM_CAL_ENTRY; ++ii)
    {
        /* Need to figure out how to handle min/max for right motor case */
        cal_cps_to_pwm[ii].pwm_min = PWM_MIN;
        cal_cps_to_pwm[ii].pwm_max = PWM_MAX;
    }
    
    memset(map_cps_to_pwm, 0, sizeof(map_cps_to_pwm));    
}

void Motor_Start()
{
    /* Enable the power on the HB-25 motor 
       Note: The HB-25 has a specific initialization sequence that is handled in hardware.  All that is necessary in 
       software is to enable power to the HB-25 motor controller and start the PWM.  The PWM will be enabled on to the
       HB-25 signal pin when initialization completes.
     */
    HB25_Enable_Pin_Write(HB25_ENABLE);    
    HB25_PWM_Start();
    Motor_SetOutput(0);    
}

void Motor_SetOutput(int16 value)
/* Incoming value units are millimeter per second.  It must be scaled to PWM range
 */
{
    int16 cps;
    
    /* 
                 mm      count
          cps = ----- x -------
                 sec     meter
    */
    cps = value * COUNT_PER_MILLIMETER;
    
    // Use counts/s as index into map_cps_to_pwm
    if (cps >= MIN_CPS_ENTRY && cps <= MAX_CPS_ENTRY)
    {
        // factor reflects the cps-to-pwm array for reverse direction
        int factor = PWM_FACTOR(value);
        
        HB25_PWM_WriteCompare(map_cps_to_pwm[cps] + factor);
    }
}

void Motor_Stop()
{
    /* Reverse sequence to start:
        - Stop the PWM
        - Disable power to the HB-25
     */
    HB25_PWM_Stop();
    HB25_Enable_Pin_Write(HB25_DISABLE);
}

void Motor_Test()
{
}

void Motor_Calibrate()
/*
    Note: Max pwm value occurs at 144 cnts/sec which is the maximum encoder resolution which makes the maximum possible
    motor speed in mm/s: 480 * 144 / 479 = 144.3

    Map counts/sec to pwm values

    Q: There could be a difference in the pwm value associated with a counts/sec value based on whether the pwm was set
       when moving from above vs when moving from below.  How to reconcile such differences?  Well, are there actually
       differences?
    Q: Is is necessary to calibrate for every counts/sec value?  There are 144 values, could we choose 25 and then
       interpolate between them?
    A: Need to find the dead zone of the servo between 0 and forward/reverse motion


 */
{
    uint16 pwm;
    uint32 delay = 250;
    static int16 meas_cps;
    int ii;
    int jj;
    
    /* The purpose of calibration is to create a mapping between the speed of the motor (in count/sec) and the PWM
       values that produce the associated speed.
    
       Calibration is performed in three steps:
    
        1. Run the motor over the range of PWM values calculating the speed after each increment and storing min/max pwm
           values for each count/sec calculation.
            Note: Limit the count/sec range to a usable range
        2. Create a mapping of pwm min/max samples and array position to be used in linear interpolation.
        3. Calculate average pwm values from the min/max samples
        4. Linear interpolate between each marker
    
     */
    
    
    /* 
        Sample the pwm values from full forward to stop
        Note: This code works the same for both left and right motors in that forward and reverse are with respect to
        the robot and not the motor
     */
    for (pwm = PWM_FULL_FORWARD; pwm > PWM_STOP; pwm += PWM_DECREMENT*PWM_CAL_STEP)
    {   
        meas_cps = 0;
        HB25_PWM_WriteCompare(pwm);
        CyDelay(PWM_SETTLE_TIME); // Allow the motor to settle before measuing the speed
        
        // Measure the speed and calculate an average
        for (ii = 0; ii < 10; ++ii)
        {
            meas_cps += CalcCountsPerSecond(delay);
        }
        meas_cps /= 10;
        
        // Constrain the measurement to the calibration range and store min/max pwm values
        if (meas_cps >= 1 && meas_cps < MAX_CAL_ENTRY)
        {            
            if (pwm < cal_cps_to_pwm[meas_cps].pwm_min)
            {
                cal_cps_to_pwm[meas_cps].pwm_min = pwm;
            }
            if (pwm > cal_cps_to_pwm[meas_cps].pwm_max)
            {
                cal_cps_to_pwm[meas_cps].pwm_max = pwm;
            }
        }        
    }

    HB25_PWM_WriteCompare(PWM_STOP);
    
    /* 
        1. Calculate the average value for each min/max pwm pair and store it to map_cps_to_pwm 
        2. Create an array of markers that holds the index of each sample point (where there are legitimate pwm values)
     */
    int marker_index = 0;
    for (ii = 1; ii < MAX_NUM_CAL_ENTRY; ++ii)
    {
        if (cal_cps_to_pwm[ii].pwm_min != PWM_MIN && cal_cps_to_pwm[ii].pwm_max != PWM_MAX)
        {
            if (ii >= MIN_CPS_ENTRY && ii <= MAX_CPS_ENTRY)
            {
                map_cps_to_pwm[ii] = (cal_cps_to_pwm[ii].pwm_min + cal_cps_to_pwm[ii].pwm_max)/2;
            
                markers[marker_index] = ii;
                marker_index++;
            }
        }
    }

    /* Linear interpolate the values 
        1. Loop over the markers array creating a delta, span and step between each sample
        2. Fill in the spaces between each sample with the interpolated values    
    */
    
    for (ii = 0; ii < MAX_NUM_MARKERS - 1; ++ii)
    {
        // Get the ith and ith+1 sample and calculate the delta
        int curr_pwm = map_cps_to_pwm[markers[ii]];
        int next_pwm = map_cps_to_pwm[markers[ii+1]];
        int delta = next_pwm - curr_pwm;
        
        // Calculate the span between samples
        int span = markers[ii+1] - markers[ii];
        // Use float so we benefit from round up
        float step = ((float) delta) / span;
        
        float value = curr_pwm;
        for (jj = markers[ii]+1; jj <= markers[ii] + span - 1; ++jj)
        {
            // Round up so we don't lose significance
            value = round(value + step);
            map_cps_to_pwm[jj] = (int) value;
        }
    }
    
    /* The following code tests that each entry selects a pwm value and results in an wheel speed matching the count/s
       index
    
     */
    
    for (ii = MIN_CPS_ENTRY; ii <= MAX_CPS_ENTRY; ++ii)
    {
        meas_cps = 0;
        HB25_PWM_WriteCompare(map_cps_to_pwm[ii]);
        CyDelay(PWM_SETTLE_TIME);
        for (jj = 0; jj < 5; ++jj)
        {
            meas_cps += CalcCountsPerSecond(500);
        }
        meas_cps /= 5;
    }
    
    HB25_PWM_WriteCompare(PWM_STOP);      
}


/* [] END OF FILE */
